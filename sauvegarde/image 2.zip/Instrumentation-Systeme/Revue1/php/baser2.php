<?php
   
  include_once("database.php");
    // Connexion à la base de données
     $idcom = connect_DB();
     
     $conso="SELECT consommation FROM MesureRL";//selectionner seulement la consommation
     $temps_marche="SELECT tmp_marche FROM MesureRL";//le but est d'afficher que la consommation d'energie Wh

    afficheValeur($temps_marche,$idcom);
    echo "\n"."\n";
    afficheValeur($conso,$idcom,"A"); 
  ?>