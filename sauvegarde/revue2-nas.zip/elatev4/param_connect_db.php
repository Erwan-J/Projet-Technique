<?php
	define("HOST","localhost");
	define("USER","root");
	define("PASS","adminsn2");
	define("BASE","instrumentation_systemes");
?>