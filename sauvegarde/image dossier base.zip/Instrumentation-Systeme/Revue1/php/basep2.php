<?php

 //    // On se connecte à MySQL
include_once("database.php");
    // Connexion à la base de données
   	$idcom = connect_DB();
 
   	$inclinaison="SELECT Inclination_panneau FROM as2 ORDER BY ID DESC ";//selcetionner seulement la consommation
   	$orientation="SELECT Orientation_panneau FROM as2 ORDER BY ID DESC";
    $tension="SELECT V_Panneau FROM as2 ORDER BY ID DESC";
    $courant="SELECT I_Panneau FROM as2 ORDER BY ID DESC";
    $temps_marche="SELECT Horodatage FROM as2 ORDER BY ID DESC";
   	//////////////////////////////////////////////////////
   	afficheValeur($orientation,$idcom,"deg");
   	echo"\n"."\n";
   	afficheValeur($inclinaison,$idcom,"deg");
    echo"\n"."\n";
   	afficheValeur($courant,$idcom,"A");
    echo"\n"."\n";
    afficheValeur($temps_marche,$idcom); 

//ajouter un parametre d'unité a la fonction ??


?>